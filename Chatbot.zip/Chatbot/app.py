from flask import Flask, render_template, request, jsonify
import os
import google.generativeai as genai
from dotenv import load_dotenv

app = Flask(__name__)

# Load API key from .env file
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Gemini model
model = genai.GenerativeModel("gemini-1.5-pro-latest")

# Role definition
ROLE = "Indian Route and Distance Guide"

# Chat session initialized globally
chat_session = None
initialized = False

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    global chat_session, initialized
    data = request.get_json()
    prompt = data.get("message", "").strip()

    if not prompt:
        return jsonify({"reply": "Please enter a travel-related question within India."})

    try:
        # Start session if not started
        if not initialized:
            chat_session = model.start_chat()
            intro_prompt = (
                f"You are an expert in the role of: '{ROLE}'. "
                f"Answer only questions strictly related to routes, distances, travel time, "
                f"places to visit, road connectivity, tourist spots, and transportation options within India. "
                f"Remember the user's context and previous queries in the session. "
                f"Maintain a structured format for all replies using clear headers like:\n"
                f"Do not use Markdown symbols like *, **, or headings (###).\n"
                f"- Route Overview\n- Distance\n- Estimated Travel Time\n- Transport Options\n- Places to Visit\n\n"
                f"If a query is out of scope, respond with: 'This prompt is outside the scope of the assigned role: {ROLE}.'"
            )
            chat_session.send_message(intro_prompt)
            initialized = True

        # Continue the chat with the user prompt
        response = chat_session.send_message(prompt)

        if "outside the scope of the assigned role" in response.text:
            return jsonify({"reply": f"This prompt is out of scope. Please ask questions related to the role: {ROLE}."})
        else:
            return jsonify({"reply": response.text})

    except Exception as e:
        return jsonify({"reply": f"API Error: {str(e)}"})

if __name__ == "__main__":
    app.run(debug=True)